// script.js - Enhanced functionality for portfolio website
document.addEventListener('DOMContentLoaded', () => {
    
    /* =====================
       1. Menu Toggle (Hamburger Icon)
       ===================== */
    let menuIcon = document.querySelector('#menu-icon');
    let navbar = document.querySelector('.navbar');

    menuIcon.onclick = () => {
        // Toggle the 'active' class on both the icon and the navbar
        menuIcon.classList.toggle('fa-xmark'); // Change hamburger to 'X' icon
        navbar.classList.toggle('active');     // Show/Hide the navigation menu
    };

    /* =====================
       2. Scroll Active Links & Sticky Header
       ===================== */
    let sections = document.querySelectorAll('section');
    let navLinks = document.querySelectorAll('.navbar a');
    let header = document.querySelector('.header');

    window.onscroll = () => {
        // --- Active Section Link Logic ---
        let top = window.scrollY;
        
        sections.forEach(sec => {
            let offset = sec.offsetTop - 150;
            let height = sec.offsetHeight;
            let id = sec.getAttribute('id');

            if (top >= offset && top < offset + height) {
                // Remove 'active' from all links
                navLinks.forEach(links => {
                    links.classList.remove('active');
                });
                // Add 'active' to the link corresponding to the current section
                let activeLink = document.querySelector('.navbar a[href*=' + id + ']');
                if (activeLink) {
                    activeLink.classList.add('active');
                }
            }
        });

        // --- Sticky Header Logic ---
        header.classList.toggle('sticky', top > 100);

        // --- Remove Menu when link is clicked/scrolls ---
        menuIcon.classList.remove('fa-xmark');
        navbar.classList.remove('active');
    };

    /* =====================
       3. Form Submission with Email Integration
       ===================== */
    const contactForm = document.querySelector('.contact form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.querySelector('input[placeholder="Full Name"]').value;
            const email = document.querySelector('input[placeholder="Email"]').value;
            const phone = document.querySelector('input[placeholder="Phone Number"]').value;
            const subject = document.querySelector('input[placeholder="Subject"]').value;
            const message = document.querySelector('textarea').value;
            
            // Simple validation
            if (!name || !email || !message) {
                showNotification('Please fill in all required fields (Name, Email, Message).', 'error');
                return;
            }
            
            if (!isValidEmail(email)) {
                showNotification('Please enter a valid email address.', 'error');
                return;
            }
            
            // Send email using mailto with form data
            sendEmail(name, email, phone, subject, message);
            
            // Show success message
            showNotification('Thank you for your message! I will get back to you soon.', 'success');
            
            // Reset form
            contactForm.reset();
        });
    }

    /* =====================
       4. WhatsApp Integration
       ===================== */
    const whatsappIcons = document.querySelectorAll('.fa-square-whatsapp');
    
    whatsappIcons.forEach(icon => {
        icon.parentElement.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Open WhatsApp with your number
            const phoneNumber = "01886975274"; // Your WhatsApp number without dashes
            const whatsappUrl = `https://wa.me/${phoneNumber}`;
            
            // Open in new tab
            window.open(whatsappUrl, '_blank');
            
            showNotification('Opening WhatsApp...', 'info');
        });
    });

    /* =====================
       4.1 Direct Instagram Integration
       ===================== */
    const instagramIcons = document.querySelectorAll('.fa-instagram');
    
    instagramIcons.forEach(icon => {
        icon.parentElement.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Your Instagram profile URL
            const instagramUrl = "https://www.instagram.com/sha_mimulhoqmahi/";
            
            // Open Instagram directly in new tab
            window.open(instagramUrl, '_blank');
            
            showNotification('Opening Instagram profile...', 'info');
        });
    });

    /* =====================
       4.2 Direct Facebook Integration
       ===================== */
    const facebookIcons = document.querySelectorAll('.fa-facebook');
    
    // Only add event listeners if Facebook icons exist
    if (facebookIcons.length > 0) {
        facebookIcons.forEach(icon => {
            icon.parentElement.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Your Facebook profile URL
                const facebookUrl = "https://www.facebook.com/profile.php?id=61581607086661";
                
                // Open Facebook directly in new tab
                window.open(facebookUrl, '_blank');
                
                showNotification('Opening Facebook profile...', 'info');
            });
        });
    }

    /* =====================
       5. Project Modal Functionality
       ===================== */
    const projectBoxes = document.querySelectorAll('.projects-box');
    
    projectBoxes.forEach(box => {
        box.addEventListener('click', function() {
            const imgSrc = this.querySelector('img').src;
            const title = this.querySelector('h4').textContent;
            const description = this.querySelector('p').textContent;
            
            openProjectModal(imgSrc, title, description);
        });
    });

    /* =====================
       6. Service Cards Interactive Effects
       ===================== */
    const serviceBoxes = document.querySelectorAll('.services-box');
    
    serviceBoxes.forEach(box => {
        // Add click event to "Learn More" buttons
        const learnMoreBtn = box.querySelector('.btn');
        
        learnMoreBtn.addEventListener('click', function(e) {
            e.stopPropagation(); // Prevent triggering the box click event
            
            const serviceTitle = box.querySelector('h3').textContent;
            showServiceDetails(serviceTitle);
        });
        
        // Add hover animation
        box.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
        });
        
        box.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    /* =====================
       7. Hire Button Functionality
       ===================== */
    const hireBtn = document.querySelector('.home-content .btn');
    
    if (hireBtn) {
        hireBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Scroll to contact section
            document.querySelector('#contact').scrollIntoView({
                behavior: 'smooth'
            });
            
            // Add a small animation to the contact form
            setTimeout(() => {
                const contactHeading = document.querySelector('.contact .heading');
                contactHeading.style.animation = 'pulse 1s';
                
                setTimeout(() => {
                    contactHeading.style.animation = '';
                }, 1000);
            }, 500);
        });
    }

    /* =====================
       8. Social Media Links Enhancement (for remaining icons)
       ===================== */
    const socialIcons = document.querySelectorAll('.social-icons a, .footer .social a');
    
    socialIcons.forEach(icon => {
        // Skip icons we've already handled
        const iconClass = icon.querySelector('i').className;
        if (!iconClass.includes('square-whatsapp') && 
            !iconClass.includes('instagram') && 
            !iconClass.includes('facebook')) {
            
            icon.addEventListener('click', function(e) {
                e.preventDefault();
                
                const platform = iconClass;
                let platformName = '';
                
                if (platform.includes('twitter')) platformName = 'Twitter';
                else if (platform.includes('github')) platformName = 'GitHub';
                
                if (platformName) {
                    showNotification(`Redirecting to ${platformName}...`, 'info');
                }
                
                // In a real application, you would redirect to actual social media profiles
                // window.open(this.href, '_blank');
            });
        }
    });

    /* =====================
       9. Scroll Animations for Elements
       ===================== */
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('.services-box, .projects-box, .timeline-item');
        
        elements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const elementVisible = 150;
            
            if (elementTop < window.innerHeight - elementVisible) {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }
        });
    };
    
    // Set initial state for animated elements
    const animatedElements = document.querySelectorAll('.services-box, .projects-box, .timeline-item');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    });
    
    // Run once on load
    animateOnScroll();
    
    // Run on scroll
    window.addEventListener('scroll', animateOnScroll);

    /* =====================
       10. Theme Toggle Functionality
       ===================== */
    const createThemeToggle = () => {
        // Check for saved theme preference or default to dark
        const currentTheme = localStorage.getItem('theme') || 'dark';
        
        // Apply the saved theme
        document.body.setAttribute('data-theme', currentTheme);
        
        // Create theme toggle button if it doesn't exist
        if (!document.querySelector('.theme-toggle')) {
            const themeToggle = document.createElement('button');
            themeToggle.className = 'theme-toggle btn';
            themeToggle.innerHTML = '<i class="fa-solid fa-moon"></i>';
            themeToggle.style.position = 'fixed';
            themeToggle.style.bottom = '20px';
            themeToggle.style.right = '20px';
            themeToggle.style.zIndex = '1000';
            
            document.body.appendChild(themeToggle);
            
            // Set initial icon based on current theme
            if (currentTheme === 'light') {
                themeToggle.innerHTML = '<i class="fa-solid fa-sun"></i>';
            }
            
            themeToggle.addEventListener('click', () => {
                const currentTheme = document.body.getAttribute('data-theme');
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.body.setAttribute('data-theme', newTheme);
                localStorage.setItem('theme', newTheme);
                
                // Update icon
                themeToggle.innerHTML = newTheme === 'dark' 
                    ? '<i class="fa-solid fa-moon"></i>' 
                    : '<i class="fa-solid fa-sun"></i>';
                
                showNotification(`Switched to ${newTheme} mode`, 'info');
            });
        }
    };

    /* =====================
       11. Typing Animation Enhancement
       ===================== */
    const enhanceTypingAnimation = () => {
        const textAnimation = document.querySelector('.text-animation');
        
        if (textAnimation) {
            // Add a restart animation on hover
            textAnimation.addEventListener('mouseenter', () => {
                textAnimation.style.animation = 'none';
                setTimeout(() => {
                    textAnimation.style.animation = '';
                }, 10);
            });
        }
    };

    /* =====================
       HELPER FUNCTIONS
       ===================== */
    
    // Email validation
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    // Send email function
    function sendEmail(name, email, phone, subject, message) {
        // Your email address (not visible to users)
        const yourEmail = "shamimulhoqmahi007@gmail.com";
        
        // Create email subject
        const emailSubject = subject || `Message from ${name} - Portfolio Contact`;
        
        // Create email body
        let emailBody = `Name: ${name}%0D%0A`;
        emailBody += `Email: ${email}%0D%0A`;
        
        if (phone) {
            emailBody += `Phone: ${phone}%0D%0A`;
        }
        
        emailBody += `%0D%0AMessage:%0D%0A${message}`;
        
        // Create mailto link
        const mailtoLink = `mailto:${yourEmail}?subject=${encodeURIComponent(emailSubject)}&body=${emailBody}`;
        
        // Open email client
        window.location.href = mailtoLink;
    }
    
    // Notification system
    function showNotification(message, type = 'info') {
        // Remove existing notification
        const existingNotification = document.querySelector('.notification');
        if (existingNotification) {
            existingNotification.remove();
        }
        
        // Create new notification
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        // Style the notification
        notification.style.position = 'fixed';
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.padding = '15px 20px';
        notification.style.borderRadius = '5px';
        notification.style.color = 'white';
        notification.style.zIndex = '10000';
        notification.style.fontSize = '1.6rem';
        notification.style.transition = 'all 0.3s ease';
        
        // Set background color based on type
        if (type === 'error') {
            notification.style.backgroundColor = '#ff4757';
        } else if (type === 'success') {
            notification.style.backgroundColor = '#2ed573';
        } else {
            notification.style.backgroundColor = '#3742fa';
        }
        
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100px)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }
    
    // Project Modal
    function openProjectModal(imgSrc, title, description) {
        // Remove existing modal if any
        const existingModal = document.querySelector('.project-modal');
        if (existingModal) {
            existingModal.remove();
        }
        
        // Create modal
        const modal = document.createElement('div');
        modal.className = 'project-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close-modal">&times;</span>
                <img src="${imgSrc}" alt="${title}">
                <h3>${title}</h3>
                <p>${description}</p>
                <button class="btn">View Project</button>
            </div>
        `;
        
        // Style the modal
        modal.style.position = 'fixed';
        modal.style.top = '0';
        modal.style.left = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
        modal.style.display = 'flex';
        modal.style.justifyContent = 'center';
        modal.style.alignItems = 'center';
        modal.style.zIndex = '10000';
        
        const modalContent = modal.querySelector('.modal-content');
        modalContent.style.backgroundColor = 'var(--bg-color)';
        modalContent.style.padding = '2rem';
        modalContent.style.borderRadius = '1rem';
        modalContent.style.maxWidth = '500px';
        modalContent.style.width = '90%';
        modalContent.style.position = 'relative';
        modalContent.style.border = '2px solid var(--main-color)';
        
        modalContent.querySelector('img').style.width = '100%';
        modalContent.querySelector('img').style.borderRadius = '0.5rem';
        modalContent.querySelector('img').style.marginBottom = '1rem';
        
        modalContent.querySelector('h3').style.fontSize = '2.4rem';
        modalContent.querySelector('h3').style.marginBottom = '1rem';
        modalContent.querySelector('h3').style.color = 'var(--main-color)';
        
        modalContent.querySelector('p').style.fontSize = '1.6rem';
        modalContent.querySelector('p').style.marginBottom = '2rem';
        
        const closeBtn = modalContent.querySelector('.close-modal');
        closeBtn.style.position = 'absolute';
        closeBtn.style.top = '10px';
        closeBtn.style.right = '15px';
        closeBtn.style.fontSize = '3rem';
        closeBtn.style.cursor = 'pointer';
        closeBtn.style.color = 'var(--main-color)';
        
        document.body.appendChild(modal);
        
        // Close modal events
        closeBtn.addEventListener('click', () => {
            modal.remove();
        });
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }
    
    // Service Details
    function showServiceDetails(serviceTitle) {
        const serviceInfo = {
            "Marketing & Advertising Materials (Print & Digital)": "I create compelling marketing materials that capture attention and drive results. From brochures to digital ads, I ensure your brand stands out in both print and digital spaces.",
            "Branding & Identity Design": "I develop cohesive brand identities that tell your story. This includes logo design, color palettes, typography, and comprehensive brand guidelines.",
            "Digital Design": "I specialize in creating engaging digital experiences, including social media graphics, website visuals, UI/UX design, and professional presentations."
        };
        
        const description = serviceInfo[serviceTitle] || "More details about this service coming soon.";
        
        showNotification(description, 'info');
    }

    /* =====================
       INITIALIZE FEATURES
       ===================== */
    createThemeToggle();
    enhanceTypingAnimation();
    
    // Add CSS for pulse animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        /* Additional theme styles */
        body[data-theme="light"] {
            --bg-color: #f5f5f5;
            --second-bg-color: #e0e0e0;
            --text-color: #333;
        }
        
        body[data-theme="light"] .services-box:hover {
            background-color: var(--bg-color);
            color: var(--text-color);
        }
    `;
    document.head.appendChild(style);
    
    console.log('Portfolio website JavaScript loaded successfully!');
});